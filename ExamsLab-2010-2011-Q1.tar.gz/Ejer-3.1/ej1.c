#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>

#define REG_SIZE	4096
#define NUM_REG		50
int main(int argc,char *argv[])
{
	int *p[NUM_REG];
	int i,pid_fill;

	/* PEDIMOS NUM_REG REGIONES */
	for (i=0;i<NUM_REG;i++){
		p[i]=malloc(REG_SIZE);
	}
	if ((pid_fill=fork())==0){
		fprintf(stdout,"HIJO PID=%d\n",getpid());
		kill(getpid(),SIGSTOP);
		execlp("sleep","sleep","1000",(char *)0);
		exit(1);
	}
	fprintf(stdout,"PADRE PID=%d\n",getpid());
	/* Espera hasta apretar una tecla */
	printf("Aprieta una tecla para continuar. Comprueba las regiones del proceso PADRE e HIJO\n");
	getchar();
	kill(pid_fill,SIGCONT);
	/* Espera hasta apretar una tecla */
	printf("Aprieta una tecla para continuar. Comprueba las regiones del proceso PADRE e HIJO\n");
	getchar();
	kill(pid_fill,SIGCONT);
}
