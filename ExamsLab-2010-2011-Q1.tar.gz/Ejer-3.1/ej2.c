#include <stdlib.h>
#include <stdio.h>

#define REGION_SIZE 256*1024*1024

#define getCycles(low,high) __asm__ __volatile__("rdtsc": "=a"(low), "=d"(high))

static inline unsigned long long getTime(void){
	unsigned long  low, high;
	getCycles(low,high);
	return ((unsigned long long) high<<32)+low;

}

main (int argc, char ** argv){

int i,j;
int *p;
unsigned long long initTime;
unsigned long long endTime;
int region_size;
unsigned int total_alloc=0;
int nelts;
int nits;
int nprocs;
int ret;
char c;
int pid_padre;
int res;

        if (argc != 3) {
                fprintf(stdout,"usage: mem2_5 region_size iterations \n");
                exit(1);
        }
	pid_padre=getpid();
	region_size=atoi(argv[1]);
	nits =atoi(argv[2]);

	nelts = region_size/sizeof(int);

	i=0;
	while(i<nits){
	p=malloc(region_size);
	if (p == NULL){
		fprintf(stdout, "Unable to allocate the memory region total_alloc=%u\n",total_alloc);
		exit(0);
	}
	total_alloc+=region_size;	
		initTime = getTime();
		for (j=0;j<nelts;j++)
			p[j]=j;
		endTime=getTime();
		fprintf(stdout, "process: %d, iteration %d, access loop time: %llu\n",getpid(),i,(endTime-initTime));
		i++;
	}
	fprintf(stdout, "Entering endless loop total_alloc=%u\n",total_alloc);
	exit(0);
	

}
