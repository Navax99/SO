#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>


void
error (char *msg)
{
  perror (msg);
  exit (0);
}

void
usage ()
{
  char msg[128];
  sprintf (msg, "./invert fitxer\n");
  write (1, msg, strlen (msg));
  exit (0);
}

void
main (int argc, char *argv[])
{
  char c;
  int fd_in, posicio, ret, fd_out;
  int pid;
  char nom[128], posc[128];
  if (argc != 2)
    usage ();
  if ((fd_in=open(argv[1],O_RDONLY))<0) error("input file");
  sprintf (nom, "%s.inv", argv[1]);
  close (1);
  if ((fd_out = open (nom, O_WRONLY | O_CREAT | O_TRUNC, 0640)) < 0)
    error ("out");
  posicio = lseek (fd_in, 0, SEEK_END);
  close(fd_in);
  while (posicio >= 0)
    {
      pid = fork ();
      if (pid < 0)
	error ("fork");
      if (pid == 0)
	{
	  sprintf (posc, "%d", posicio);
	  execlp ("./lletra", "lletra", argv[1], posc, (char *) NULL);
	  error ("execlp");
	}
      posicio--;
      waitpid (pid, NULL, 0);
    }
}
