#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
int pid;
void
Usage ()
{
  char buff[128];
  sprintf (buff, "usage:examCAT fich1 [fich2...fichN]\n");
  write (1, buff, strlen (buff));
  exit (0);
}

void
f_alarma (int s)
{
  char buff[128];
  int exit_code;
  sprintf (buff, "Temps finalitzat\n");
  write (1, buff, strlen (buff));
  kill (pid, SIGKILL);
  waitpid (pid, &exit_code, 0);
#ifdef DEBUG
  sprintf (buff, "Acaba proces %d amb estat %d\n", pid, exit_code);
  write (1, buff, strlen (buff));
#endif
  exit (0);
}

void
main (int argc, char *argv[])
{
  int fitxer;
  char buff[128];
  int exit_code;
  if (argc == 1)
    Usage ();
  signal (SIGALRM, f_alarma);
  alarm (10);
  for (fitxer = 1; fitxer < argc; fitxer++)
    {
      pid = fork ();
      if (pid == 0)
	{
	  execlp ("cat", "cat", argv[fitxer], (char *) NULL);
	  perror ("Fallo execlp\n");
	  exit (1);
	}
      else if (pid < 0)
	{
	  perror ("Fallo fork\n");
	  exit (1);
	}
      else
	{
#ifdef DEBUG
	  sprintf (buff, "Nou process %d\n", pid);
	  write (1, buff, strlen (buff));
#endif
	  getchar ();
	  waitpid (pid, &exit_code, 0);
#ifdef DEBUG
	  sprintf (buff, "Acaba proces %d amb estat %d\n", pid, exit_code);
	  write (1, buff, strlen (buff));
#endif
	}

    }
}
