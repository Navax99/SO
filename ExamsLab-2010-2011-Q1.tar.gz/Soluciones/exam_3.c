#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
void
error (char *msg)
{
  perror (msg);
  exit(0);
}

void
main (int agrc, char *argv[])
{
  int fd[2], pid, exit_code, ret;
  char buff[128];
  int num, total;
  if (pipe (fd) < 0)
    error ("pipe");
  pid = fork ();
  if (pid < 0)
    error ("fork");
  if (pid == 0)
    {
      close (fd[0]);
      dup2 (fd[1], 1);
      close (fd[1]);
      execlp ("./exam_2", "exam_2", (char *) NULL);
      error ("execlp");
    }
  total = 0;
  close (fd[1]);
  while (read (fd[0], &num, sizeof (int)) > 0)
    total = total + num;
  close (fd[1]);
  sprintf (buff, "La suma total es %d\n", total);
  write (1, buff, strlen (buff));
}
