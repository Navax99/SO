#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
int pss;
int alarma_recibida = 0;
int seg;
void
Usage ()
{
  char buff[128];
  sprintf (buff, "usage:examPS numSeg\n");
  write (1, buff, strlen (buff));
  exit (0);
}

void
f_alarma (int s)
{
  alarma_recibida = 1;
  alarm (seg);
}

void
f_sigusr (int s)
{
  char buff[128];
  if (s == SIGUSR1)
    {
      sprintf (buff, "Mi PID es %d\n", getpid ());
    }
  else
    {
      sprintf (buff, "Llevamos %d ps's\n", pss);
    }
  write (1, buff, strlen (buff));
}

void
main (int argc, char *argv[])
{
  char buff[128];
  int pid;
  int exit_code;
  if (argc == 1)
    Usage ();
  seg = atoi (argv[1]);
  signal (SIGALRM, f_alarma);
  signal (SIGUSR1, f_sigusr);
  signal (SIGUSR2, f_sigusr);
  alarm (seg);
  for (pss = 0; pss < 5; pss++)
    {
      while (alarma_recibida == 0)
	pause ();		//esperamos que llegue el signal
      alarma_recibida = 0;
      pid = fork ();
      if (pid == 0)
	{
	  execlp ("ps", "ps", "-u", "alumne", "-o", "pid,ppid,cmd",
		  (char *) NULL);
	  perror ("Fallo execlp\n");
	  exit (1);
	}
      else if (pid < 0)
	{
	  perror ("Fallo fork\n");
	  exit (1);
	}
      else
	{
	  waitpid (pid, &exit_code, 0);
#ifdef DEBUG
	  sprintf (buff, "Acaba proces %d amb estat %d\n", pid, exit_code);
	  write (1, buff, strlen (buff));
#endif
	}

    }
}
