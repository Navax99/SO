#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void
error (char *msg)
{
  perror (msg);
  exit (0);
}

void
main (int argc, char argv[])
{
  int fd[2], fich;
  int pid, numc = 0;
  char c;
  char buff[128];
  if (pipe (fd) < 0)
    error ("pipe");
  pid = fork ();
  if (pid < 0)
    error ("fork");
  if (pid == 0)
    {
      close (fd[0]);
      dup2 (fd[1], 1);
      close (fd[1]);
      close (0);
      fich = open ("MyDevice", O_RDONLY);
      if (fich != 0)
	error ("open");
      execlp ("cat", "cat", (char *) 0);
      error ("execlp");
    }
  close (fd[1]);
  while (read (fd[0], &c, sizeof (c)) > 0)
    numc++;
  sprintf (buff, "S'han rebut %d caracters\n", numc);
  write (1, buff, strlen (buff));
  waitpid (-1, NULL, 0);
}
