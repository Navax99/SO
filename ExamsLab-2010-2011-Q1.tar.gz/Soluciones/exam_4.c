#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#define END 0
#define ESPACIO 1
#define CR 2

int fd_in, fd_out;

int
leer_palabra (char *p)
{
	int i=0,ret;
	char c;
	ret=read(fd_in,&c,sizeof(char));	
	while((ret>0) && (c!=' ') && (c!='\n')){
		p[i]=c;
		i++;
		ret=read(fd_in,&c,sizeof(char));	
	}
	p[i]='\0';
	if (i==0) return END;
	else if (c==' ') return ESPACIO;
	else return CR;
	 	
}

void
invertir_palabra (char *p1, char *p2)
{
	int s;
	int i=0;
	s=strlen(p1)-1;
	while(s>=0){
		p2[i]=p1[s];
		i++;s--;
	}
	p2[i]='\0';
}

void
escribir_palabra (char *p,int extra)
{
	write(fd_out,p,strlen(p));
	if (extra==CR) write(fd_out,"\n",1);
	else write(fd_out," ",1);
}

void
error (char *msg)
{
  perror (msg);
  exit (0);
}

void
usage ()
{
  char msg[128];
  sprintf (msg, "./exam_4 fitxer_input\n");
  write (1, msg, strlen (msg));
  exit (0);
}

void
main (int argc, char *argv[])
{
  char palabra[128];
  char palabra_inv[128];
  char file_out[128];
  int extra;
  if (argc == 1)
    usage ();
  if ((fd_in = open (argv[1], O_RDONLY)) < 0)
    error ("open input");
  sprintf (file_out, "%s.inv", argv[1]);
  if ((fd_out = open (file_out, O_WRONLY | O_CREAT | O_TRUNC,0640)) < 0)
    error ("open output");
  while ((extra=leer_palabra (palabra)) > 0)
    {
      invertir_palabra (palabra, palabra_inv);
      escribir_palabra (palabra_inv,extra);
    }
}
