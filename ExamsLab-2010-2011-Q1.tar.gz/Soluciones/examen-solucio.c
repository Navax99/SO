#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

#define DEFAULT_SIZE 4096

int region_size = DEFAULT_SIZE;
char *p;
int i;

#define getCycles(low,high) __asm__ __volatile__("rdtsc": "=a"(low), "=d"(high))

static inline unsigned long long getTime(void){
	unsigned long  low, high;
	getCycles(low,high);
	return ((unsigned long long) high<<32)+low;
}

void Usage(void)
{
	fprintf(stdout, "Usage: examen [mida_regio]\n");
}

/* Funcio d'atencio al SIGSEGV */
void handler(int sig)
{
        signal(SIGSEGV, handler);
        fprintf(stdout, "Proces %d: Segmentation fault\n", getpid());
        exit(0);
}

int main(int argc, char *argv[])
{
	pid_t pid;
	int tmp;
	
	unsigned long long initTime;
	unsigned long long endTime;
	
	/* Programem SIGSEGV */
        signal(SIGSEGV, handler);

	/* Comprovem arguments */
	if (argc > 2) {
		Usage();
		exit(1);
	}
	if (argc == 2)
		region_size = atoi(argv[1]);	
	
	/* Reservem region_size bytes */
	p = malloc(region_size);
	if (p == NULL) {
		fprintf(stdout, "Error en el malloc.\n");
		exit(1);
	}

	/* Bucle 1 */
	initTime = getTime();	
	for (i=0; i<region_size; i++)
		p[i] = i;
	endTime=getTime();
	fprintf(stdout, "Proces %d. Temps bucle 1: %llu\n", getpid(), endTime-initTime);

	/* Creem el proces fill */
	if ((pid = fork()) < 0) {
		perror("Error en el fork: ");
		exit(1);
	}

	/* Bucle 2 */
	initTime = getTime();
	for (i=0; i<region_size; i++) {
		tmp = p[i];
	}
	endTime=getTime();
	fprintf(stdout, "Proces %d. Temps bucle 2: %llu\n", getpid(), endTime-initTime);
	
	/* Bucle 3 */
	initTime = getTime();
	if (pid == 0) {
		for (i=0; i<region_size; i++)
			p[i] = i;
	} else {
		for (i=0; i<region_size; i++)
			tmp = p[i];
	}
	endTime=getTime();
	fprintf(stdout, "Proces %d. Temps bucle 3: %llu\n", getpid(), endTime-initTime);

	/* Escriu AQUI el codi per mostrar les adreces de les variables que demana l'enunciat */
	fprintf(stdout, "Proces %d. Adreca de i: %p\n", getpid(), &i);
	fprintf(stdout, "Proces %d. Adreca de region_size: %p\n", getpid(), &region_size);
	fprintf(stdout, "Proces %d. Adreca de tmp: %p\n", getpid(), &tmp);
	fprintf(stdout, "Proces %d. Adreca del bloc: %p\n", getpid(), p);
	
	/* Esperem una tecla i al fill */
	if (pid > 0) {
		if (wait(NULL) < 0) {
			perror("Error en el wait: ");
		}
		fprintf(stdout, "Prem una tecla per acabar...\n");
		getchar();
	}
	free(p);

	exit(0);
}

