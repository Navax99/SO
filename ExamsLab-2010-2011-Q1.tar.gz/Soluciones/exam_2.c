#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int
leer_numero ()
{
  int i = 0, ret;
  char num[16];
  char c;
  ret = read (0, &c, sizeof (c));
  while ((ret > 0) && (c != '\n'))
    {
      num[i] = c;
      i++;
      ret = read (0, &c, sizeof (c));
    }
  if (i == 0)
    return -1;
  num[i] = '\0';
  return atoi (num);
}



void
main (int argc, char *argv[])
{
  int num;
  while ((num = leer_numero ()) != -1)
    {
      write (1, &num, sizeof (num));
    }
}
