#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>


void
error (char *msg)
{
  perror (msg);
  exit (0);
}

void
usage ()
{
  char msg[128];
  sprintf (msg, "./lletra fitxer posicio\n");
  write (1, msg, strlen (msg));
  exit (0);
}

void
main (int argc, char *argv[])
{
  char c;
  int fd_in,posicio,ret;

  posicio=atoi(argv[2]);
  if (argc !=3)
    usage ();
  if ((fd_in = open (argv[1], O_RDONLY)) < 0)
    error ("open input");
  ret=lseek(fd_in,posicio,SEEK_SET);
  if (ret!=posicio) exit(0);
  ret=read(fd_in,&c,sizeof(char));
  if (ret<0) error("read");
  write(1,&c,sizeof(char));  
}
