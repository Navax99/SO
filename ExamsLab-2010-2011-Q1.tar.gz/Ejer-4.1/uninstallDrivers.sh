#!/bin/bash

if [ $# -ne 1 ]
then
	echo "usage: ./installDrivers.sh [myDriver1.ko]"
	exit
fi

sudo rmmod $1
